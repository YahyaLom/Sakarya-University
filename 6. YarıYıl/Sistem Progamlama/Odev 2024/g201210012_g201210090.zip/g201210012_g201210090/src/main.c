#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fields.h"

#define MAX_ADI_UZUNLUK 100
int main()
{
    IS is; // fields.h a ait bir yapı
    FILE *girisDosyasi,
        *ciktiDosyasi, *tempFile;
    char komut[100];
    char *komutAdi;
    char sembol;
    char nokta = '.';
    int adet;
    char *yahya;
    char kontrol;
    char girisDosyasiAdi[MAX_ADI_UZUNLUK];
    char cikisDosyasiAdi[MAX_ADI_UZUNLUK];
    printf("Silme isleminden sonra sonagit: komutu yoksa uzerine yazarak ilerlemeye devam etmektedir bu sekilde bilerek yapilmistir...");
    printf("\n");
    printf("Giris dosya adini giriniz: ");
    if (scanf("%s", girisDosyasiAdi) != 1)
    {
        strcpy(girisDosyasiAdi, "giris.dat");
        girisDosyasi = fopen("giris.dat", "r");
    }
    else
    {
    	const char *filename = girisDosyasiAdi; // Dosya adı
        girisDosyasi = fopen(girisDosyasiAdi, "r");
    }
    is = new_inputstruct(girisDosyasiAdi);
    if (is == NULL) {
        fprintf(stderr, "Dosya açma hatası: %s\n", girisDosyasiAdi);
        return 1;
    }
    if (girisDosyasi == NULL)
    {
        printf("Giris dosyasi acilamadi.\n");
        return 1;
    }

    printf("Cikis dosya adini giriniz: ");
    if (scanf("%s", cikisDosyasiAdi) != 1)
    {
        strcpy(cikisDosyasiAdi, "cikti.dat");
        ciktiDosyasi = fopen("cikti.dat", "w+");
    }
    else
    {
        ciktiDosyasi = fopen(cikisDosyasiAdi, "w+");
    }
    if (ciktiDosyasi == NULL)
    {
        printf("Cikti dosyasi acilamadi.\n");
        return 1;
    }

    char ch;
    tempFile = fopen("gecici.dat", "w");
    fclose(tempFile);
    ///////////////////////////////////////////////////////////
    while (get_line(is) >= 0) 
    {
        // Satırın ilk alanına göre işlem yap
        if (is->NF > 0) {
            if (strcmp(is->fields[0], "yaz:") == 0) {
            continue;

            } else if (strcmp(is->fields[0], "sil:") == 0) {
            continue;

            } else if (strcmp(is->fields[0], "sonagit:") == 0) {
            continue;

            } else if (strcmp(is->fields[0], "dur:") == 0) {
            continue;

            } else {
            printf("Dosya icerisinde uyumusz bir satir bulundu...");

            }
        }
        }
	//////////////////////////////////////////////////
	rewind(girisDosyasi);
    while (fgets(komut, sizeof(komut), girisDosyasi) != NULL)
    {
        komutAdi = strtok(komut, " ");
        if (strcmp(komutAdi, "yaz:") == 0)
        {
            char *arg;
            while ((arg = strtok(NULL, " \n")) != NULL)
            {
                adet = atoi(arg);
                if (adet <= 0)
                {
                    printf("Hata: Gecersiz adet\n");
                    continue;
                }
                arg = strtok(NULL, " \n");
                if (arg == NULL || strlen(arg) != 1)
                {
                    // printf("geçersiz sembol bloğu -> %c", arg);
                    if (arg[1] == 'b')
                    {
                        for (int yahya = 0; yahya < adet; yahya++)
                        {
                            fprintf(ciktiDosyasi, " ");
                        }
                        continue;
                    }
                    else if (arg[1] == 'n')
                    {
                        for (int yahya = 0; yahya < adet; yahya++)
                        {
                            fprintf(ciktiDosyasi, "\n");
                        }
                        continue;
                    }
                }
                sembol = arg[0];

                for (int i = 0; i < adet; i++)
                {
                    // fputc(sembol, ciktiDosyasi);
                    fprintf(ciktiDosyasi, "%c", sembol);
                }
            }
        }
        else if (strcmp(komutAdi, "sil:") == 0)
        {

            char *arg;
            while ((arg = strtok(NULL, " \n")) != NULL)
            {
                adet = atoi(arg);
                arg = strtok(NULL, " \n");
                sembol = arg[0];
                int sayac = 0;
                // printf("mustafa ya %d adet %c sembol silmeli -> \n", adet, sembol);
                long int firstPosition = ftell(ciktiDosyasi);
                for (int mustafa = 0; mustafa <= adet;)
                {
                    if (ftell(ciktiDosyasi) == 0)
                    {
                        printf("\n\nDosyanin basina kadar gelindi ama uygun silme elemani bulunamadi");
                        break;
                    }

                    fseek(ciktiDosyasi, -1, SEEK_CUR);

                    char karakter = fgetc(ciktiDosyasi);
                    // printf("\nokunan karakter -> %c", karakter);
                    sayac++;
                    if (karakter == '\n')
                    {
                        fseek(ciktiDosyasi, -1, SEEK_CUR);
                    }

                    if (karakter == sembol)
                    {
                        fseek(ciktiDosyasi, -1, SEEK_CUR);
                        mustafa++;
                        // printf("\nsilinen karakter -> %c", karakter);
                        fputc(nokta, ciktiDosyasi);
                    }
                    fseek(ciktiDosyasi, -1, SEEK_CUR);
                    if (mustafa == adet)
                    {
                        mustafa++;
                        firstPosition = ftell(ciktiDosyasi);
                        // printf("Konumum -> %ld", firstPosition);
                    }
                }
            }
            long int silmeBittiKonumu = ftell(ciktiDosyasi);
            tempFile = fopen("gecici.dat", "w+");
            rewind(ciktiDosyasi);
            char okunanHarf;
            do
            {
                okunanHarf = getc(ciktiDosyasi);
                if (okunanHarf == nokta)
                {
                    continue;
                }
                else if (okunanHarf == EOF)
                {
                    continue;
                }
                else
                {
                    fputc(okunanHarf, tempFile);
                }

            } while (okunanHarf != EOF);
            // fputc('0', tempFile);
            fclose(tempFile);
            fclose(ciktiDosyasi);
            remove(cikisDosyasiAdi);
            // rename("cikti.dat", "sil.dat");
            rename("gecici.dat", cikisDosyasiAdi);
            ciktiDosyasi = fopen(cikisDosyasiAdi, "r+");
            fseek(ciktiDosyasi, silmeBittiKonumu, SEEK_SET);
        }
        else
        {
            yahya = strtok(komut, ":");
            if (strcmp(yahya, "sonagit") == 0)
            {
                fseek(ciktiDosyasi, 0, SEEK_END);
            }
            else if (strcmp(yahya, "dur") == 0)
            {
            jettison_inputstruct(is);
                printf("Dosya islemleri sonlandirildi.");
                printf("\nSonuclari %s dosyasinda gorebilirsiniz.", cikisDosyasiAdi);
                fclose(girisDosyasi);
                fclose(ciktiDosyasi);
                return 0;
            }
            else
            {
                printf("Bilinmeyen komut !!!");
                printf("?-> %s\n", komutAdi);
                // fprintf(ciktiDosyasi, "Hata: Bilinmeyen komut\n");
                continue;
            }
        }
    }
    

    return 0;
}
