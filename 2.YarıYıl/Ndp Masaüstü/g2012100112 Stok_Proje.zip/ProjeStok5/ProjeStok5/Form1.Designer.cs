﻿namespace ProjeStok5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Raf = new System.Windows.Forms.ListBox();
            this.Depo = new System.Windows.Forms.ListBox();
            this.Tedarikçiler = new System.Windows.Forms.ListBox();
            this.Giderler = new System.Windows.Forms.ListBox();
            this.Müşteriler = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtÜrünID = new System.Windows.Forms.TextBox();
            this.txtÜrünFiyatı = new System.Windows.Forms.TextBox();
            this.txtTedarikçi = new System.Windows.Forms.TextBox();
            this.txtÜrünAdedi = new System.Windows.Forms.TextBox();
            this.btnRafKaydet = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnDepoKaydet = new System.Windows.Forms.Button();
            this.btnDepoSil = new System.Windows.Forms.Button();
            this.btnDepoDüzenle = new System.Windows.Forms.Button();
            this.btnTedarikçiKaydet = new System.Windows.Forms.Button();
            this.btnTedarikçiSil = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMüşteriTc = new System.Windows.Forms.TextBox();
            this.txtMüşteriAdıVeSoyadı = new System.Windows.Forms.TextBox();
            this.btnMüşteriKaydet = new System.Windows.Forms.Button();
            this.btnMüşteriSil = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtEleman = new System.Windows.Forms.TextBox();
            this.txtElektrik = new System.Windows.Forms.TextBox();
            this.txtSu = new System.Windows.Forms.TextBox();
            this.txtDiger = new System.Windows.Forms.TextBox();
            this.btnGiderKaydet = new System.Windows.Forms.Button();
            this.btnGiderSil = new System.Windows.Forms.Button();
            this.btnTemizle = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.btnRafAl = new System.Windows.Forms.Button();
            this.btnRafDüzenle = new System.Windows.Forms.Button();
            this.btnDepoAl = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblÜrünIDGelen = new System.Windows.Forms.Label();
            this.lblMüşteriTC = new System.Windows.Forms.Label();
            this.lblSiparişTedarikçi = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.btnLabelTemizle = new System.Windows.Forms.Button();
            this.lblPaha = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.txtSiparişAdet = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.btnÜrünAl = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.txtSiparişMüşteri = new System.Windows.Forms.TextBox();
            this.MüşteriSiparişleri = new System.Windows.Forms.ListBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblDepodakiStok = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.btnAktarÜrünü = new System.Windows.Forms.Button();
            this.btnMalTemizle = new System.Windows.Forms.Button();
            this.btnMalÇek = new System.Windows.Forms.Button();
            this.btnTedarikçiAktar = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.lblMalFiyat = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.lblMalÜrünId = new System.Windows.Forms.Label();
            this.lblMalTedarikçi = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.TedarikçiSiparişleri = new System.Windows.Forms.ListBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.btnRafTxt = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.lblCiroHesapla = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Raf
            // 
            this.Raf.FormattingEnabled = true;
            this.Raf.ItemHeight = 20;
            this.Raf.Location = new System.Drawing.Point(959, 37);
            this.Raf.Name = "Raf";
            this.Raf.Size = new System.Drawing.Size(598, 104);
            this.Raf.TabIndex = 0;
            // 
            // Depo
            // 
            this.Depo.FormattingEnabled = true;
            this.Depo.ItemHeight = 20;
            this.Depo.Location = new System.Drawing.Point(959, 169);
            this.Depo.Name = "Depo";
            this.Depo.Size = new System.Drawing.Size(598, 104);
            this.Depo.TabIndex = 1;
            // 
            // Tedarikçiler
            // 
            this.Tedarikçiler.FormattingEnabled = true;
            this.Tedarikçiler.ItemHeight = 20;
            this.Tedarikçiler.Location = new System.Drawing.Point(959, 308);
            this.Tedarikçiler.Name = "Tedarikçiler";
            this.Tedarikçiler.Size = new System.Drawing.Size(302, 104);
            this.Tedarikçiler.TabIndex = 2;
            // 
            // Giderler
            // 
            this.Giderler.FormattingEnabled = true;
            this.Giderler.ItemHeight = 20;
            this.Giderler.Location = new System.Drawing.Point(959, 457);
            this.Giderler.Name = "Giderler";
            this.Giderler.Size = new System.Drawing.Size(598, 104);
            this.Giderler.TabIndex = 3;
            // 
            // Müşteriler
            // 
            this.Müşteriler.FormattingEnabled = true;
            this.Müşteriler.ItemHeight = 20;
            this.Müşteriler.Location = new System.Drawing.Point(1267, 308);
            this.Müşteriler.Name = "Müşteriler";
            this.Müşteriler.Size = new System.Drawing.Size(290, 104);
            this.Müşteriler.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ürün ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ürün Fiyatı";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tedarikçi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ürün Adedi";
            // 
            // txtÜrünID
            // 
            this.txtÜrünID.Location = new System.Drawing.Point(123, 7);
            this.txtÜrünID.Name = "txtÜrünID";
            this.txtÜrünID.Size = new System.Drawing.Size(125, 27);
            this.txtÜrünID.TabIndex = 9;
            // 
            // txtÜrünFiyatı
            // 
            this.txtÜrünFiyatı.Location = new System.Drawing.Point(123, 40);
            this.txtÜrünFiyatı.Name = "txtÜrünFiyatı";
            this.txtÜrünFiyatı.Size = new System.Drawing.Size(125, 27);
            this.txtÜrünFiyatı.TabIndex = 10;
            // 
            // txtTedarikçi
            // 
            this.txtTedarikçi.Location = new System.Drawing.Point(123, 74);
            this.txtTedarikçi.Name = "txtTedarikçi";
            this.txtTedarikçi.Size = new System.Drawing.Size(125, 27);
            this.txtTedarikçi.TabIndex = 11;
            // 
            // txtÜrünAdedi
            // 
            this.txtÜrünAdedi.Location = new System.Drawing.Point(123, 107);
            this.txtÜrünAdedi.Name = "txtÜrünAdedi";
            this.txtÜrünAdedi.Size = new System.Drawing.Size(125, 27);
            this.txtÜrünAdedi.TabIndex = 12;
            // 
            // btnRafKaydet
            // 
            this.btnRafKaydet.Location = new System.Drawing.Point(313, 6);
            this.btnRafKaydet.Name = "btnRafKaydet";
            this.btnRafKaydet.Size = new System.Drawing.Size(127, 29);
            this.btnRafKaydet.TabIndex = 13;
            this.btnRafKaydet.Text = "Raf Kaydet";
            this.btnRafKaydet.UseVisualStyleBackColor = true;
            this.btnRafKaydet.Click += new System.EventHandler(this.btnRafKaydet_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(459, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 29);
            this.button2.TabIndex = 14;
            this.button2.Text = "Raf Sil";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(6, 214);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(125, 29);
            this.button3.TabIndex = 15;
            this.button3.Text = "Sipariş Oluştur";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnDepoKaydet
            // 
            this.btnDepoKaydet.Location = new System.Drawing.Point(313, 55);
            this.btnDepoKaydet.Name = "btnDepoKaydet";
            this.btnDepoKaydet.Size = new System.Drawing.Size(127, 29);
            this.btnDepoKaydet.TabIndex = 16;
            this.btnDepoKaydet.Text = "Depo Kaydet";
            this.btnDepoKaydet.UseVisualStyleBackColor = true;
            this.btnDepoKaydet.Click += new System.EventHandler(this.btnDepoKaydet_Click);
            // 
            // btnDepoSil
            // 
            this.btnDepoSil.Location = new System.Drawing.Point(467, 55);
            this.btnDepoSil.Name = "btnDepoSil";
            this.btnDepoSil.Size = new System.Drawing.Size(94, 29);
            this.btnDepoSil.TabIndex = 17;
            this.btnDepoSil.Text = "Depo Sil";
            this.btnDepoSil.UseVisualStyleBackColor = true;
            this.btnDepoSil.Click += new System.EventHandler(this.btnDepoSil_Click);
            // 
            // btnDepoDüzenle
            // 
            this.btnDepoDüzenle.Location = new System.Drawing.Point(695, 55);
            this.btnDepoDüzenle.Name = "btnDepoDüzenle";
            this.btnDepoDüzenle.Size = new System.Drawing.Size(116, 29);
            this.btnDepoDüzenle.TabIndex = 18;
            this.btnDepoDüzenle.Text = "Depo Düzenle";
            this.btnDepoDüzenle.UseVisualStyleBackColor = true;
            this.btnDepoDüzenle.Click += new System.EventHandler(this.btnDepoDüzenle_Click);
            // 
            // btnTedarikçiKaydet
            // 
            this.btnTedarikçiKaydet.Location = new System.Drawing.Point(313, 101);
            this.btnTedarikçiKaydet.Name = "btnTedarikçiKaydet";
            this.btnTedarikçiKaydet.Size = new System.Drawing.Size(127, 29);
            this.btnTedarikçiKaydet.TabIndex = 19;
            this.btnTedarikçiKaydet.Text = "Tedarikçi Kaydet";
            this.btnTedarikçiKaydet.UseVisualStyleBackColor = true;
            this.btnTedarikçiKaydet.Click += new System.EventHandler(this.btnTedarikçiKaydet_Click);
            // 
            // btnTedarikçiSil
            // 
            this.btnTedarikçiSil.Location = new System.Drawing.Point(459, 101);
            this.btnTedarikçiSil.Name = "btnTedarikçiSil";
            this.btnTedarikçiSil.Size = new System.Drawing.Size(102, 29);
            this.btnTedarikçiSil.TabIndex = 20;
            this.btnTedarikçiSil.Text = "Tedarikçi Sil";
            this.btnTedarikçiSil.UseVisualStyleBackColor = true;
            this.btnTedarikçiSil.Click += new System.EventHandler(this.btnTedarikçiSil_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 189);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 20);
            this.label5.TabIndex = 21;
            this.label5.Text = "Müşteri TC";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(-4, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 50);
            this.label6.TabIndex = 22;
            this.label6.Text = "Müşteri Adı Ve Soyadı";
            // 
            // txtMüşteriTc
            // 
            this.txtMüşteriTc.Location = new System.Drawing.Point(123, 189);
            this.txtMüşteriTc.Name = "txtMüşteriTc";
            this.txtMüşteriTc.Size = new System.Drawing.Size(125, 27);
            this.txtMüşteriTc.TabIndex = 23;
            // 
            // txtMüşteriAdıVeSoyadı
            // 
            this.txtMüşteriAdıVeSoyadı.Location = new System.Drawing.Point(123, 237);
            this.txtMüşteriAdıVeSoyadı.Name = "txtMüşteriAdıVeSoyadı";
            this.txtMüşteriAdıVeSoyadı.Size = new System.Drawing.Size(125, 27);
            this.txtMüşteriAdıVeSoyadı.TabIndex = 24;
            // 
            // btnMüşteriKaydet
            // 
            this.btnMüşteriKaydet.Location = new System.Drawing.Point(313, 205);
            this.btnMüşteriKaydet.Name = "btnMüşteriKaydet";
            this.btnMüşteriKaydet.Size = new System.Drawing.Size(127, 29);
            this.btnMüşteriKaydet.TabIndex = 25;
            this.btnMüşteriKaydet.Text = "Müşteri Kaydet";
            this.btnMüşteriKaydet.UseVisualStyleBackColor = true;
            this.btnMüşteriKaydet.Click += new System.EventHandler(this.btnMüşteriKaydet_Click);
            // 
            // btnMüşteriSil
            // 
            this.btnMüşteriSil.Location = new System.Drawing.Point(459, 205);
            this.btnMüşteriSil.Name = "btnMüşteriSil";
            this.btnMüşteriSil.Size = new System.Drawing.Size(102, 29);
            this.btnMüşteriSil.TabIndex = 26;
            this.btnMüşteriSil.Text = "Müşteri Sil";
            this.btnMüşteriSil.UseVisualStyleBackColor = true;
            this.btnMüşteriSil.Click += new System.EventHandler(this.btnMüşteriSil_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 315);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 20);
            this.label7.TabIndex = 27;
            this.label7.Text = "Eleman";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 350);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 20);
            this.label8.TabIndex = 28;
            this.label8.Text = "Elektrik";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(53, 388);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 20);
            this.label9.TabIndex = 29;
            this.label9.Text = "Su";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 425);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 20);
            this.label10.TabIndex = 30;
            this.label10.Text = "Diger";
            // 
            // txtEleman
            // 
            this.txtEleman.Location = new System.Drawing.Point(123, 308);
            this.txtEleman.Name = "txtEleman";
            this.txtEleman.Size = new System.Drawing.Size(125, 27);
            this.txtEleman.TabIndex = 31;
            // 
            // txtElektrik
            // 
            this.txtElektrik.Location = new System.Drawing.Point(123, 348);
            this.txtElektrik.Name = "txtElektrik";
            this.txtElektrik.Size = new System.Drawing.Size(125, 27);
            this.txtElektrik.TabIndex = 32;
            // 
            // txtSu
            // 
            this.txtSu.Location = new System.Drawing.Point(123, 385);
            this.txtSu.Name = "txtSu";
            this.txtSu.Size = new System.Drawing.Size(125, 27);
            this.txtSu.TabIndex = 33;
            // 
            // txtDiger
            // 
            this.txtDiger.Location = new System.Drawing.Point(123, 425);
            this.txtDiger.Name = "txtDiger";
            this.txtDiger.Size = new System.Drawing.Size(125, 27);
            this.txtDiger.TabIndex = 34;
            // 
            // btnGiderKaydet
            // 
            this.btnGiderKaydet.Location = new System.Drawing.Point(313, 362);
            this.btnGiderKaydet.Name = "btnGiderKaydet";
            this.btnGiderKaydet.Size = new System.Drawing.Size(127, 29);
            this.btnGiderKaydet.TabIndex = 35;
            this.btnGiderKaydet.Text = "Gider Kaydet";
            this.btnGiderKaydet.UseVisualStyleBackColor = true;
            this.btnGiderKaydet.Click += new System.EventHandler(this.btnGiderKaydet_Click);
            // 
            // btnGiderSil
            // 
            this.btnGiderSil.Location = new System.Drawing.Point(467, 362);
            this.btnGiderSil.Name = "btnGiderSil";
            this.btnGiderSil.Size = new System.Drawing.Size(94, 29);
            this.btnGiderSil.TabIndex = 36;
            this.btnGiderSil.Text = "Gider Sil";
            this.btnGiderSil.UseVisualStyleBackColor = true;
            this.btnGiderSil.Click += new System.EventHandler(this.btnGiderSil_Click);
            // 
            // btnTemizle
            // 
            this.btnTemizle.Location = new System.Drawing.Point(123, 476);
            this.btnTemizle.Name = "btnTemizle";
            this.btnTemizle.Size = new System.Drawing.Size(125, 29);
            this.btnTemizle.TabIndex = 37;
            this.btnTemizle.Text = "Temizle";
            this.btnTemizle.UseVisualStyleBackColor = true;
            this.btnTemizle.Click += new System.EventHandler(this.btnTemizle_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(959, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 20);
            this.label11.TabIndex = 38;
            this.label11.Text = "ID";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(998, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 20);
            this.label12.TabIndex = 39;
            this.label12.Text = "Fiyat";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1053, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 20);
            this.label13.TabIndex = 40;
            this.label13.Text = "Tedarikçi";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1127, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 20);
            this.label14.TabIndex = 41;
            this.label14.Text = "Adet";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(959, 146);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(24, 20);
            this.label15.TabIndex = 42;
            this.label15.Text = "ID";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(998, 146);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 20);
            this.label16.TabIndex = 43;
            this.label16.Text = "Fiyat";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(1053, 146);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 20);
            this.label17.TabIndex = 44;
            this.label17.Text = "Tedarikçi";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(1127, 146);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 20);
            this.label18.TabIndex = 45;
            this.label18.Text = "Adet";
            // 
            // btnRafAl
            // 
            this.btnRafAl.Location = new System.Drawing.Point(575, 7);
            this.btnRafAl.Name = "btnRafAl";
            this.btnRafAl.Size = new System.Drawing.Size(94, 29);
            this.btnRafAl.TabIndex = 46;
            this.btnRafAl.Text = "Raf Al";
            this.btnRafAl.UseVisualStyleBackColor = true;
            this.btnRafAl.Click += new System.EventHandler(this.btnRafAl_Click);
            // 
            // btnRafDüzenle
            // 
            this.btnRafDüzenle.Location = new System.Drawing.Point(695, 7);
            this.btnRafDüzenle.Name = "btnRafDüzenle";
            this.btnRafDüzenle.Size = new System.Drawing.Size(112, 29);
            this.btnRafDüzenle.TabIndex = 47;
            this.btnRafDüzenle.Text = "Raf Düzenle";
            this.btnRafDüzenle.UseVisualStyleBackColor = true;
            this.btnRafDüzenle.Click += new System.EventHandler(this.btnRafDüzenle_Click);
            // 
            // btnDepoAl
            // 
            this.btnDepoAl.Location = new System.Drawing.Point(575, 55);
            this.btnDepoAl.Name = "btnDepoAl";
            this.btnDepoAl.Size = new System.Drawing.Size(94, 29);
            this.btnDepoAl.TabIndex = 48;
            this.btnDepoAl.Text = "Depo Al";
            this.btnDepoAl.UseVisualStyleBackColor = true;
            this.btnDepoAl.Click += new System.EventHandler(this.btnDepoAl_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 41);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 20);
            this.label19.TabIndex = 49;
            this.label19.Text = "Müşteri TC";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblÜrünIDGelen);
            this.groupBox1.Controls.Add(this.lblMüşteriTC);
            this.groupBox1.Controls.Add(this.lblSiparişTedarikçi);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.btnLabelTemizle);
            this.groupBox1.Controls.Add(this.lblPaha);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.txtSiparişAdet);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.btnÜrünAl);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Location = new System.Drawing.Point(23, 588);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(438, 249);
            this.groupBox1.TabIndex = 50;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sipariş";
            // 
            // lblÜrünIDGelen
            // 
            this.lblÜrünIDGelen.AutoSize = true;
            this.lblÜrünIDGelen.Location = new System.Drawing.Point(111, 78);
            this.lblÜrünIDGelen.Name = "lblÜrünIDGelen";
            this.lblÜrünIDGelen.Size = new System.Drawing.Size(0, 20);
            this.lblÜrünIDGelen.TabIndex = 65;
            // 
            // lblMüşteriTC
            // 
            this.lblMüşteriTC.AutoSize = true;
            this.lblMüşteriTC.Location = new System.Drawing.Point(100, 41);
            this.lblMüşteriTC.Name = "lblMüşteriTC";
            this.lblMüşteriTC.Size = new System.Drawing.Size(0, 20);
            this.lblMüşteriTC.TabIndex = 64;
            // 
            // lblSiparişTedarikçi
            // 
            this.lblSiparişTedarikçi.AutoSize = true;
            this.lblSiparişTedarikçi.Location = new System.Drawing.Point(343, 215);
            this.lblSiparişTedarikçi.Name = "lblSiparişTedarikçi";
            this.lblSiparişTedarikçi.Size = new System.Drawing.Size(0, 20);
            this.lblSiparişTedarikçi.TabIndex = 63;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(250, 215);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(68, 20);
            this.label40.TabIndex = 62;
            this.label40.Text = "Tedarikçi";
            // 
            // btnLabelTemizle
            // 
            this.btnLabelTemizle.Location = new System.Drawing.Point(137, 214);
            this.btnLabelTemizle.Name = "btnLabelTemizle";
            this.btnLabelTemizle.Size = new System.Drawing.Size(94, 29);
            this.btnLabelTemizle.TabIndex = 61;
            this.btnLabelTemizle.Text = "Temizle";
            this.btnLabelTemizle.UseVisualStyleBackColor = true;
            this.btnLabelTemizle.Click += new System.EventHandler(this.btnLabelTemizle_Click);
            // 
            // lblPaha
            // 
            this.lblPaha.AutoSize = true;
            this.lblPaha.Location = new System.Drawing.Point(343, 175);
            this.lblPaha.Name = "lblPaha";
            this.lblPaha.Size = new System.Drawing.Size(0, 20);
            this.lblPaha.TabIndex = 60;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(244, 139);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(73, 20);
            this.label35.TabIndex = 59;
            this.label35.Text = "Max Adet";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(263, 175);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(44, 20);
            this.label34.TabIndex = 58;
            this.label34.Text = "Fiyat ";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(352, 139);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(0, 20);
            this.label33.TabIndex = 57;
            // 
            // txtSiparişAdet
            // 
            this.txtSiparişAdet.Location = new System.Drawing.Point(100, 131);
            this.txtSiparişAdet.Name = "txtSiparişAdet";
            this.txtSiparişAdet.Size = new System.Drawing.Size(125, 27);
            this.txtSiparişAdet.TabIndex = 56;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(21, 138);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 20);
            this.label32.TabIndex = 55;
            this.label32.Text = "Adet";
            // 
            // btnÜrünAl
            // 
            this.btnÜrünAl.Location = new System.Drawing.Point(273, 78);
            this.btnÜrünAl.Name = "btnÜrünAl";
            this.btnÜrünAl.Size = new System.Drawing.Size(111, 29);
            this.btnÜrünAl.TabIndex = 54;
            this.btnÜrünAl.Text = "Ürün Aktar";
            this.btnÜrünAl.UseVisualStyleBackColor = true;
            this.btnÜrünAl.Click += new System.EventHandler(this.btnÜrünAl_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(273, 36);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 29);
            this.button1.TabIndex = 53;
            this.button1.Text = "Müşteri Aktar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(9, 78);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(63, 20);
            this.label31.TabIndex = 51;
            this.label31.Text = "Ürün ID ";
            // 
            // txtSiparişMüşteri
            // 
            this.txtSiparişMüşteri.Location = new System.Drawing.Point(113, 157);
            this.txtSiparişMüşteri.Name = "txtSiparişMüşteri";
            this.txtSiparişMüşteri.Size = new System.Drawing.Size(125, 27);
            this.txtSiparişMüşteri.TabIndex = 50;
            // 
            // MüşteriSiparişleri
            // 
            this.MüşteriSiparişleri.FormattingEnabled = true;
            this.MüşteriSiparişleri.ItemHeight = 20;
            this.MüşteriSiparişleri.Location = new System.Drawing.Point(959, 600);
            this.MüşteriSiparişleri.Name = "MüşteriSiparişleri";
            this.MüşteriSiparişleri.Size = new System.Drawing.Size(598, 104);
            this.MüşteriSiparişleri.TabIndex = 51;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1526, 121);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 20);
            this.label20.TabIndex = 52;
            this.label20.Text = "Raf";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1511, 253);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 20);
            this.label21.TabIndex = 53;
            this.label21.Text = "Depo";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(1176, 392);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(85, 20);
            this.label22.TabIndex = 54;
            this.label22.Text = "Tedarikçiler";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(1482, 392);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(75, 20);
            this.label23.TabIndex = 55;
            this.label23.Text = "Müşteriler";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1495, 541);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(62, 20);
            this.label24.TabIndex = 56;
            this.label24.Text = "Giderler";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1430, 684);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(127, 20);
            this.label25.TabIndex = 57;
            this.label25.Text = "Müşteri Siparişleri";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(959, 285);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(24, 20);
            this.label26.TabIndex = 58;
            this.label26.Text = "ID";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(998, 285);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 20);
            this.label27.TabIndex = 59;
            this.label27.Text = "Fiyat";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1053, 285);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(68, 20);
            this.label28.TabIndex = 60;
            this.label28.Text = "Tedarikçi";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1267, 280);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(25, 20);
            this.label29.TabIndex = 61;
            this.label29.Text = "TC";
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1298, 280);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(28, 20);
            this.label30.TabIndex = 62;
            this.label30.Text = "Ad";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(959, 577);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(24, 20);
            this.label36.TabIndex = 63;
            this.label36.Text = "ID";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(998, 577);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(25, 20);
            this.label37.TabIndex = 64;
            this.label37.Text = "TC";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(1053, 577);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(40, 20);
            this.label38.TabIndex = 65;
            this.label38.Text = "Fiyat";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(1110, 577);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 20);
            this.label39.TabIndex = 66;
            this.label39.Text = "Adet";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblDepodakiStok);
            this.groupBox2.Controls.Add(this.label50);
            this.groupBox2.Controls.Add(this.btnAktarÜrünü);
            this.groupBox2.Controls.Add(this.btnMalTemizle);
            this.groupBox2.Controls.Add(this.btnMalÇek);
            this.groupBox2.Controls.Add(this.btnTedarikçiAktar);
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.lblMalFiyat);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.lblMalÜrünId);
            this.groupBox2.Controls.Add(this.lblMalTedarikçi);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.txtSiparişMüşteri);
            this.groupBox2.Location = new System.Drawing.Point(477, 588);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(415, 249);
            this.groupBox2.TabIndex = 67;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Mal Kabul";
            // 
            // lblDepodakiStok
            // 
            this.lblDepodakiStok.AutoSize = true;
            this.lblDepodakiStok.Location = new System.Drawing.Point(140, 130);
            this.lblDepodakiStok.Name = "lblDepodakiStok";
            this.lblDepodakiStok.Size = new System.Drawing.Size(0, 20);
            this.lblDepodakiStok.TabIndex = 57;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(2, 134);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(105, 20);
            this.label50.TabIndex = 56;
            this.label50.Text = "Depodaki stok";
            // 
            // btnAktarÜrünü
            // 
            this.btnAktarÜrünü.Location = new System.Drawing.Point(280, 78);
            this.btnAktarÜrünü.Name = "btnAktarÜrünü";
            this.btnAktarÜrünü.Size = new System.Drawing.Size(117, 29);
            this.btnAktarÜrünü.TabIndex = 55;
            this.btnAktarÜrünü.Text = "Depodan Ürün";
            this.btnAktarÜrünü.UseVisualStyleBackColor = true;
            this.btnAktarÜrünü.Click += new System.EventHandler(this.btnAktarÜrünü_Click);
            // 
            // btnMalTemizle
            // 
            this.btnMalTemizle.Location = new System.Drawing.Point(155, 208);
            this.btnMalTemizle.Name = "btnMalTemizle";
            this.btnMalTemizle.Size = new System.Drawing.Size(94, 29);
            this.btnMalTemizle.TabIndex = 54;
            this.btnMalTemizle.Text = "Temizle";
            this.btnMalTemizle.UseVisualStyleBackColor = true;
            this.btnMalTemizle.Click += new System.EventHandler(this.btnMalTemizle_Click);
            // 
            // btnMalÇek
            // 
            this.btnMalÇek.Location = new System.Drawing.Point(36, 208);
            this.btnMalÇek.Name = "btnMalÇek";
            this.btnMalÇek.Size = new System.Drawing.Size(94, 29);
            this.btnMalÇek.TabIndex = 53;
            this.btnMalÇek.Text = "Mal Çek";
            this.btnMalÇek.UseVisualStyleBackColor = true;
            this.btnMalÇek.Click += new System.EventHandler(this.btnMalÇek_Click);
            // 
            // btnTedarikçiAktar
            // 
            this.btnTedarikçiAktar.Location = new System.Drawing.Point(280, 38);
            this.btnTedarikçiAktar.Name = "btnTedarikçiAktar";
            this.btnTedarikçiAktar.Size = new System.Drawing.Size(117, 29);
            this.btnTedarikçiAktar.TabIndex = 51;
            this.btnTedarikçiAktar.Text = "Tedarikçi Aktar";
            this.btnTedarikçiAktar.UseVisualStyleBackColor = true;
            this.btnTedarikçiAktar.Click += new System.EventHandler(this.btnTedarikçiAktar_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(32, 164);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(72, 20);
            this.label43.TabIndex = 6;
            this.label43.Text = "Yeni Adet";
            // 
            // lblMalFiyat
            // 
            this.lblMalFiyat.AutoSize = true;
            this.lblMalFiyat.Location = new System.Drawing.Point(129, 105);
            this.lblMalFiyat.Name = "lblMalFiyat";
            this.lblMalFiyat.Size = new System.Drawing.Size(0, 20);
            this.lblMalFiyat.TabIndex = 5;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(33, 105);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(40, 20);
            this.label45.TabIndex = 4;
            this.label45.Text = "Fiyat";
            // 
            // lblMalÜrünId
            // 
            this.lblMalÜrünId.AutoSize = true;
            this.lblMalÜrünId.Location = new System.Drawing.Point(129, 72);
            this.lblMalÜrünId.Name = "lblMalÜrünId";
            this.lblMalÜrünId.Size = new System.Drawing.Size(0, 20);
            this.lblMalÜrünId.TabIndex = 3;
            // 
            // lblMalTedarikçi
            // 
            this.lblMalTedarikçi.AutoSize = true;
            this.lblMalTedarikçi.Location = new System.Drawing.Point(129, 37);
            this.lblMalTedarikçi.Name = "lblMalTedarikçi";
            this.lblMalTedarikçi.Size = new System.Drawing.Size(0, 20);
            this.lblMalTedarikçi.TabIndex = 2;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(33, 72);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(55, 20);
            this.label42.TabIndex = 1;
            this.label42.Text = "ÜrünID";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(33, 38);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(68, 20);
            this.label41.TabIndex = 0;
            this.label41.Text = "Tedarikçi";
            // 
            // TedarikçiSiparişleri
            // 
            this.TedarikçiSiparişleri.FormattingEnabled = true;
            this.TedarikçiSiparişleri.ItemHeight = 20;
            this.TedarikçiSiparişleri.Location = new System.Drawing.Point(959, 733);
            this.TedarikçiSiparişleri.Name = "TedarikçiSiparişleri";
            this.TedarikçiSiparişleri.Size = new System.Drawing.Size(598, 104);
            this.TedarikçiSiparişleri.TabIndex = 68;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(1420, 817);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(137, 20);
            this.label44.TabIndex = 69;
            this.label44.Text = "Tedarikçi Siparişleri";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(959, 709);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(24, 20);
            this.label46.TabIndex = 70;
            this.label46.Text = "ID";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(998, 710);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(40, 20);
            this.label47.TabIndex = 71;
            this.label47.Text = "Fiyat";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(1053, 710);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(68, 20);
            this.label48.TabIndex = 72;
            this.label48.Text = "Tedarikçi";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(1127, 709);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(41, 20);
            this.label49.TabIndex = 73;
            this.label49.Text = "Adet";
            // 
            // btnRafTxt
            // 
            this.btnRafTxt.Location = new System.Drawing.Point(681, 169);
            this.btnRafTxt.Name = "btnRafTxt";
            this.btnRafTxt.Size = new System.Drawing.Size(151, 29);
            this.btnRafTxt.TabIndex = 74;
            this.btnRafTxt.Text = "Rafı Listele";
            this.btnRafTxt.UseVisualStyleBackColor = true;
            this.btnRafTxt.Click += new System.EventHandler(this.btnRafTxt_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(681, 205);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(151, 29);
            this.button4.TabIndex = 75;
            this.button4.Text = "Depo Listele";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(590, 306);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(151, 29);
            this.button5.TabIndex = 76;
            this.button5.Text = "Ciro Listele";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(590, 273);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(151, 29);
            this.button6.TabIndex = 77;
            this.button6.Text = "Ciro Hesapla";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // lblCiroHesapla
            // 
            this.lblCiroHesapla.AutoSize = true;
            this.lblCiroHesapla.Location = new System.Drawing.Point(777, 278);
            this.lblCiroHesapla.Name = "lblCiroHesapla";
            this.lblCiroHesapla.Size = new System.Drawing.Size(0, 20);
            this.lblCiroHesapla.TabIndex = 78;
            // 
            // label51
            // 
            this.label51.Location = new System.Drawing.Point(575, 101);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(288, 100);
            this.label51.TabIndex = 79;
            this.label51.Text = "önce düzeltmek istenilen veri seçilir, sonra al butonuna basılır ve düzenleme yap" +
    "ıldıktan sonra düzenle butonuna basılır";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(74, 563);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(366, 20);
            this.label52.TabIndex = 80;
            this.label52.Text = "önce işlem yapılacak ürün ve müşteri seçilir ve aktarılır";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(459, 563);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(486, 20);
            this.label53.TabIndex = 81;
            this.label53.Text = "önce işlem yapılacak ürün ve tedarikçi seçilir , aktarılır sonra işlem yapılır";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(313, 244);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(264, 20);
            this.label54.TabIndex = 82;
            this.label54.Text = "silmeden önce silinecek veri seçilmeli...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1585, 866);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.lblCiroHesapla);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnRafTxt);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.TedarikçiSiparişleri);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.MüşteriSiparişleri);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDepoAl);
            this.Controls.Add(this.btnRafDüzenle);
            this.Controls.Add(this.btnRafAl);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnTemizle);
            this.Controls.Add(this.btnGiderSil);
            this.Controls.Add(this.btnGiderKaydet);
            this.Controls.Add(this.txtDiger);
            this.Controls.Add(this.txtSu);
            this.Controls.Add(this.txtElektrik);
            this.Controls.Add(this.txtEleman);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnMüşteriSil);
            this.Controls.Add(this.btnMüşteriKaydet);
            this.Controls.Add(this.txtMüşteriAdıVeSoyadı);
            this.Controls.Add(this.txtMüşteriTc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnTedarikçiSil);
            this.Controls.Add(this.btnTedarikçiKaydet);
            this.Controls.Add(this.btnDepoDüzenle);
            this.Controls.Add(this.btnDepoSil);
            this.Controls.Add(this.btnDepoKaydet);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnRafKaydet);
            this.Controls.Add(this.txtÜrünAdedi);
            this.Controls.Add(this.txtTedarikçi);
            this.Controls.Add(this.txtÜrünFiyatı);
            this.Controls.Add(this.txtÜrünID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Müşteriler);
            this.Controls.Add(this.Giderler);
            this.Controls.Add(this.Tedarikçiler);
            this.Controls.Add(this.Depo);
            this.Controls.Add(this.Raf);
            this.Name = "Form1";
            this.Text = "Stok Takip";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListBox Raf;
        private ListBox Depo;
        private ListBox Tedarikçiler;
        private ListBox Giderler;
        private ListBox Müşteriler;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtÜrünID;
        private TextBox txtÜrünFiyatı;
        private TextBox txtTedarikçi;
        private TextBox txtÜrünAdedi;
        private Button btnRafKaydet;
        private Button button2;
        private Button button3;
        private Button btnDepoKaydet;
        private Button btnDepoSil;
        private Button btnDepoDüzenle;
        private Button btnTedarikçiKaydet;
        private Button btnTedarikçiSil;
        private Label label5;
        private Label label6;
        private TextBox txtMüşteriTc;
        private TextBox txtMüşteriAdıVeSoyadı;
        private Button btnMüşteriKaydet;
        private Button btnMüşteriSil;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private TextBox txtEleman;
        private TextBox txtElektrik;
        private TextBox txtSu;
        private TextBox txtDiger;
        private Button btnGiderKaydet;
        private Button btnGiderSil;
        private Button btnTemizle;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Button btnRafAl;
        private Button btnRafDüzenle;
        private Button btnDepoAl;
        private Label label19;
        private GroupBox groupBox1;
        private ListBox MüşteriSiparişleri;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private Label label27;
        private Label label28;
        private Label label29;
        private Label label30;
        private Label label31;
        private TextBox txtSiparişMüşteri;
        private Button btnÜrünAl;
        private Button button1;
        private TextBox txtSiparişAdet;
        private Label label32;
        private Label label33;
        private Label lblPaha;
        private Label label35;
        private Label label34;
        private Label label36;
        private Label label37;
        private Label label38;
        private Label label39;
        private Button btnLabelTemizle;
        private Label lblSiparişTedarikçi;
        private Label label40;
        private GroupBox groupBox2;
        private Label lblMüşteriTC;
        private Label lblÜrünIDGelen;
        private Button btnMalTemizle;
        private Button btnMalÇek;
        private Button btnTedarikçiAktar;
        private Label label43;
        private Label lblMalFiyat;
        private Label label45;
        private Label lblMalÜrünId;
        private Label lblMalTedarikçi;
        private Label label42;
        private Label label41;
        private ListBox TedarikçiSiparişleri;
        private Label label44;
        private Label label46;
        private Label label47;
        private Label label48;
        private Label label49;
        private Button btnAktarÜrünü;
        private Label lblDepodakiStok;
        private Label label50;
        private Button btnRafTxt;
        private Button button4;
        private Button button5;
        private Button button6;
        private Label lblCiroHesapla;
        private Label label51;
        private Label label52;
        private Label label53;
        private Label label54;
    }
}