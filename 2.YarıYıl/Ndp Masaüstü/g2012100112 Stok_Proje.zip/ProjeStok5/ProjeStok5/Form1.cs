using System.Diagnostics;
using System.IO;
namespace ProjeStok5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRafKaydet_Click(object sender, EventArgs e)
        {
            string �r�nID, �r�nFiyat�, Tedarik�i, �r�nAdedi;
            �r�nID = txt�r�nID.Text;
            �r�nFiyat� = txt�r�nFiyat�.Text;
            Tedarik�i = txtTedarik�i.Text;
            �r�nAdedi = txt�r�nAdedi.Text;
            Raf.Items.Add(�r�nID + "/" + �r�nFiyat� + "/" + Tedarik�i + "/" + �r�nAdedi);


        }

        private void btnDepoKaydet_Click(object sender, EventArgs e)
        {
            string �r�nID, �r�nFiyat�, Tedarik�i, �r�nAdedi;
            �r�nID = txt�r�nID.Text;
            �r�nFiyat� = txt�r�nFiyat�.Text;
            Tedarik�i = txtTedarik�i.Text;
            �r�nAdedi = txt�r�nAdedi.Text;

            Depo.Items.Add(�r�nID + "/" + �r�nFiyat� + "/" + Tedarik�i + "/" + �r�nAdedi);
        }

        private void btnTedarik�iKaydet_Click(object sender, EventArgs e)
        {
            string �r�nID, �r�nFiyat�, Tedarik�i;
            int gecici;
            �r�nID = txt�r�nID.Text;
            �r�nFiyat� = txt�r�nFiyat�.Text;
            Tedarik�i = txtTedarik�i.Text;
            //gecici = Convert.ToInt32(�r�nFiyat�);


            Tedarik�iler.Items.Add(�r�nID + "/" + �r�nFiyat� + "/" + Tedarik�i);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Raf.Items.Remove(Raf.SelectedItem);
        }

        private void btnDepoSil_Click(object sender, EventArgs e)
        {
            Depo.Items.Remove(Depo.SelectedItem);
        }

        private void btnTedarik�iSil_Click(object sender, EventArgs e)
        {
            Tedarik�iler.Items.Remove(Tedarik�iler.SelectedItem);
        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            txt�r�nAdedi.Clear();
            txt�r�nFiyat�.Clear();
            txtTedarik�i.Clear();
            txt�r�nID.Clear();
            txtM��teriAd�VeSoyad�.Clear();
            txtM��teriTc.Clear();
            txtEleman.Clear();
            txtElektrik.Clear();
            txtDiger.Clear();
            txtSu.Clear();
            lblCiroHesapla.Text = "";


        }

        private void btnM��teriSil_Click(object sender, EventArgs e)
        {
            M��teriler.Items.Remove(M��teriler.SelectedItem);
        }

        private void btnM��teriKaydet_Click(object sender, EventArgs e)
        {
            string M��teriTc, M��teriAd�VeSoyad�;
            M��teriAd�VeSoyad� = txtM��teriAd�VeSoyad�.Text;
            M��teriTc = txtM��teriTc.Text;
            M��teriler.Items.Add(M��teriTc + "/" + M��teriAd�VeSoyad�);
        }

        private void btnGiderKaydet_Click(object sender, EventArgs e)
        {
            int Eleman, Elektrik, Su, Diger;
            Eleman = Convert.ToInt32(txtEleman.Text);
            Elektrik = Convert.ToInt32(txtElektrik.Text);
            Su = Convert.ToInt32(txtSu.Text);
            Diger = Convert.ToInt32(txtDiger.Text);

            Giderler.Items.Add( Eleman + "/" +  Elektrik + "/" + Su + "/"  + Diger);
        }

        private void btnGiderSil_Click(object sender, EventArgs e)
        {
            Giderler.Items.Remove(Giderler.SelectedItem);
        }

        private void button3_Click(object sender, EventArgs e)
        {


            int denetleyici = Convert.ToInt32(txtSipari�Adet.Text);
            int denetleyici2 = Convert.ToInt32(label33.Text);

            if (denetleyici <= denetleyici2)
            {
                int Kalan = denetleyici2 - denetleyici;

                string Sipari�M��teri, Sipari��r�nID;
                Sipari�M��teri = lblM��teriTC.Text;
                Sipari��r�nID = lbl�r�nIDGelen.Text;
                string Tedarik�i = lblSipari�Tedarik�i.Text;
                string �r�nFiyat� = lblPaha.Text;
                string �r�nAdedi = label33.Text;
                M��teriSipari�leri.Items.Add(Sipari��r�nID + "/" + Sipari�M��teri + "/" + �r�nFiyat� + "/" + �r�nAdedi);
                Raf.Items.Remove(Raf.SelectedItem);

                //label33.Text = Convert.ToString(Kalan);
                �r�nAdedi = Convert.ToString(Kalan);
                //string Tedarik�i= lblSipari�Tedarik�i.Text;
                //string �r�nFiyat� = lblPaha.Text;
                //string �r�nAdedi = label33.Text;
                Raf.Items.Add(Sipari��r�nID + "/" + �r�nFiyat� + "/" + Tedarik�i + "/" + �r�nAdedi);


            }
            else
            {
                MessageBox.Show("Adet Say�s�na dikkat ediniz...");
                txtSipari�Adet.Clear();

            }



        }

        private void btnRafAl_Click(object sender, EventArgs e)
        {
            string alici = Raf.SelectedItem.ToString();
            char[] ayirici = new char[] { '/' };
            string[] tasiyici = alici.Split(ayirici);

            txt�r�nID.Text = tasiyici[0];
            txt�r�nFiyat�.Text = tasiyici[1];
            txtTedarik�i.Text = tasiyici[2];
            txt�r�nAdedi.Text = tasiyici[3];
        }

        private void btnDepoAl_Click(object sender, EventArgs e)
        {
            string alici = Depo.SelectedItem.ToString();
            char[] ayirici = new char[] { '/' };
            string[] tasiyici = alici.Split(ayirici);

            txt�r�nID.Text = tasiyici[0];
            txt�r�nFiyat�.Text = tasiyici[1];
            txtTedarik�i.Text = tasiyici[2];
            txt�r�nAdedi.Text = tasiyici[3];
        }

        private void btnRafD�zenle_Click(object sender, EventArgs e)
        {
            Raf.Items.Remove(Raf.SelectedItem);
            string �r�nID, �r�nFiyat�, Tedarik�i, �r�nAdedi;
            �r�nID = txt�r�nID.Text;
            �r�nFiyat� = txt�r�nFiyat�.Text;
            Tedarik�i = txtTedarik�i.Text;
            �r�nAdedi = txt�r�nAdedi.Text;
            Raf.Items.Add(�r�nID + "/" + �r�nFiyat� + "/" + Tedarik�i + "/" + �r�nAdedi);
        }

        private void btnDepoD�zenle_Click(object sender, EventArgs e)
        {
            Depo.Items.Remove(Depo.SelectedItem);
            string �r�nID, �r�nFiyat�, Tedarik�i, �r�nAdedi;
            �r�nID = txt�r�nID.Text;
            �r�nFiyat� = txt�r�nFiyat�.Text;
            Tedarik�i = txtTedarik�i.Text;
            �r�nAdedi = txt�r�nAdedi.Text;
            Depo.Items.Add(�r�nID + "/" + �r�nFiyat� + "/" + Tedarik�i + "/" + �r�nAdedi);
        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string alici = M��teriler.SelectedItem.ToString();
            char[] ayirici = new char[] { '/' };
            string[] tasiyici = alici.Split(ayirici);
            lblM��teriTC.Text = tasiyici[0];
            //txtSipari�M��teri.Text = tasiyici[0];

        }

        private void btn�r�nAl_Click(object sender, EventArgs e)
        {
            string alici = Raf.SelectedItem.ToString();
            char[] ayirici = new char[] { '/' };
            string[] tasiyici = alici.Split(ayirici);

            // txtSipari��r�nID.Text = tasiyici[0];
            lbl�r�nIDGelen.Text = tasiyici[0];
            lblPaha.Text = tasiyici[1];
            lblSipari�Tedarik�i.Text = tasiyici[2];
            label33.Text = tasiyici[3];

        }

        private void btnLabelTemizle_Click(object sender, EventArgs e)
        {
            label33.Text = "";
            lblPaha.Text = "";
            //txtSipari�M��teri.Clear();
            txtSipari�Adet.Clear();
            //txtSipari��r�nID.Clear();
            lblSipari�Tedarik�i.Text = "";
            lblM��teriTC.Text = "";
            lbl�r�nIDGelen.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnTedarik�iAktar_Click(object sender, EventArgs e)
        {
            string alici = Tedarik�iler.SelectedItem.ToString();
            char[] ayirici = new char[] { '/' };
            string[] tasiyici = alici.Split(ayirici);
            //lblMal�r�nId.Text = tasiyici[0];
            lblMalFiyat.Text = tasiyici[1];
            lblMalTedarik�i.Text = tasiyici[2];


        }

        private void btnMalTemizle_Click(object sender, EventArgs e)
        {
            lblMalFiyat.Text = "";
            lblMal�r�nId.Text = "";
            lblMalTedarik�i.Text = "";
            txtSipari�M��teri.Clear();
        }
        //��rn �d yi depodan al ve yeni mal �kem i�lemini ekle ve �yle depoya kaydet
        private void btnMal�ek_Click(object sender, EventArgs e)
        {
            string Sipari�Tedarik�i, Sipari�Tedarik�i�r�nID, MalFiyat, MalAdet;
            Sipari�Tedarik�i = lblMalTedarik�i.Text;
            Sipari�Tedarik�i�r�nID = lblMal�r�nId.Text;
            MalFiyat = lblMalFiyat.Text;
            MalAdet = txtSipari�M��teri.Text;
            Tedarik�iSipari�leri.Items.Add(Sipari�Tedarik�i�r�nID + "/" + MalFiyat + "/" + Sipari�Tedarik�i + "/" + MalAdet);

            string st1, st2, st3, st4;
            st1 = lblMal�r�nId.Text;
            st2 = lblMalFiyat.Text;
            st3 = lblMalTedarik�i.Text;
            int i = Convert.ToInt32(lblDepodakiStok.Text);
            int j = Convert.ToInt32(txtSipari�M��teri.Text);
            int t = i + j;
            st4 = Convert.ToString(t);
            Depo.Items.Remove(Depo.SelectedItem);
            Depo.Items.Add(st1 + "/" + st2 + "/" + st3 + "/" + st4);
        }

        private void btnAktar�r�n�_Click(object sender, EventArgs e)
        {
            string alici = Depo.SelectedItem.ToString();
            char[] ayirici = new char[] { '/' };
            string[] tasiyici = alici.Split(ayirici);
            lblMal�r�nId.Text = tasiyici[0];
            lblDepodakiStok.Text = tasiyici[3];


        }

        private void btnRafTxt_Click(object sender, EventArgs e)
        {
            string DosyaYolu = @"C:\Stok/Raf.txt";
            string[] Kay�tDizisi = new string[Raf.Items.Count];
            Raf.Items.CopyTo(Kay�tDizisi, 0);
            System.IO.File.WriteAllLines(DosyaYolu, Kay�tDizisi);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string DosyaYolu = @"C:\Stok/Depo.txt";
            string[] Kay�tDizisi = new string[Depo.Items.Count];
            Raf.Items.CopyTo(Kay�tDizisi, 0);
            System.IO.File.WriteAllLines(DosyaYolu, Kay�tDizisi);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string alici = Giderler.SelectedItem.ToString();
            char[] ayirici = new char[] { '/' };
            string[] tasiyici = alici.Split(ayirici);
            int a = Convert.ToInt32(tasiyici[0]);
            int b = Convert.ToInt32(tasiyici[1]);
            int c = Convert.ToInt32(tasiyici[2]);
            int d = Convert.ToInt32(tasiyici[3]);
            int gider = a + b + c + d;
            lblCiroHesapla.Text = (Convert.ToString(gider)+" tl");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string DosyaYolu = @"C:\Stok/Giderler.txt";
            string[] Kay�tDizisi = new string[Giderler.Items.Count];
            Giderler.Items.CopyTo(Kay�tDizisi, 0);
            System.IO.File.WriteAllLines(DosyaYolu, Kay�tDizisi);
        }
    }
}